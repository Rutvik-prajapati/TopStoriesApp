import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  apiKeyForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.apiKeyForm = this.fb.group({
      apiKey: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[a-zA-Z0-9]{32}$/), // API Key format validation
        ],
      ],
    });
  }

  get apiKey() {
    return this.apiKeyForm.get('apiKey');
  }

  onSubmit() {
    if (this.apiKeyForm.valid) {
      alert('API Key Submitted: ' + this.apiKeyForm.value.apiKey);
    }
  }
}
