import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
    providedIn: 'root'
  })
  export class TopStoriesService {
  
    constructor(private http : HttpClient) { }
  
    private _baseUrl = environment.baseUrl + '/api/TopStories';
  
    getAllTopStories():Observable<any>{
        return this.http.get(`${this._baseUrl}/GetAllStories`);
    }

    saveTopStories(apiKey:string){
      return this.http.post(`${this._baseUrl}/SaveTopStories`,apiKey);
    }
  }