﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace TopStoriesAPI.Model
{
    public class TopStoriesModel
    {
        public string Status { get; set; }
        public string Copyright { get; set; }
        public string Section { get; set; }
        [JsonProperty("last_updated")]
        public DateTime? LastUpdated { get; set; }
        public int NumResults { get; set; }
        public List<Article> Results { get; set; }
    }

    public class Article
    {
        public string Section { get; set; }
        public string Subsection { get; set; }
        public string Title { get; set; }
        public string Abstract { get; set; }
        public string Url { get; set; }
        public string Uri { get; set; }
        public string Byline { get; set; }
        public string ItemType { get; set; }
        [JsonProperty("updated_date")]
        public DateTime? UpdatedDate { get; set; }
        [JsonProperty("created_date")]
        public DateTime? CreatedDate { get; set; }
        [JsonProperty("published_date")]
        public DateTime? PublishedDate { get; set; }
        [JsonProperty("material_type_facet")]
        public string MaterialTypeFacet { get; set; }
        public string Kicker { get; set; }
        [JsonProperty("des_facet")]
        public List<string> DesFacet { get; set; }
        [JsonProperty("org_facet")]
        public List<string> OrgFacet { get; set; }
        [JsonProperty("per_facet")]
        public List<string> PerFacet { get; set; }
        [JsonProperty("geo_facet")]
        public List<string> GeoFacet { get; set; }
        public List<Multimedia> Multimedia { get; set; }
        [JsonProperty("short_url")]
        public string ShortUrl { get; set; }
    }

    public class Multimedia
    {
        public string Url { get; set; }
        public string Format { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public string Type { get; set; }
        public string Subtype { get; set; }
        public string Caption { get; set; }
        public string Copyright { get; set; }
    }

}
