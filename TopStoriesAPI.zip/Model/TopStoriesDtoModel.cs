﻿using TopStoriesAPI.Models;

namespace TopStoriesAPI.Model
{
    public class TopStoriesDtoModel
    {
        public List<ArticalDto> TopStories { get; set; }
    }

    public class ArticalDto
    {
        public int Id { get; set; }

        public string? Section { get; set; }

        public string? Subsection { get; set; }

        public string? Title { get; set; }

        public string? Abstract { get; set; }

        public string? Url { get; set; }

        public string? Uri { get; set; }

        public string? Byline { get; set; }

        public string? ItemType { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? PublishedDate { get; set; }

        public string? MaterialTypeFacet { get; set; }

        public string? Kicker { get; set; }

        public List<DesFacetsDto> DesFacets { get; set; } = new();

        public List<GeoFacetsDto> GeoFacets { get; set; } = new();

        public List<MultimediaDto> Multimedia { get; set; } = new();

        public List<PerFacetsDto> PerFacets { get; set; } = new();
    }

    public class MultimediaDto
    {
        public int Id { get; set; }

        public int? ArticleId { get; set; }

        public string? Url { get; set; }

        public string? Format { get; set; }

        public int? Height { get; set; }

        public int? Width { get; set; }

        public string? Type { get; set; }

        public string? Subtype { get; set; }

        public string? Caption { get; set; }

        public string? Copyright { get; set; }

    }
    public class DesFacetsDto
    {
        public int Id { get; set; }

        public int? ArticleId { get; set; }

        public string? Facet { get; set; }

    }

    public class PerFacetsDto
    {
        public int Id { get; set; }

        public int? ArticleId { get; set; }

        public string? Person { get; set; }

    }

    public class GeoFacetsDto
    {
        public int Id { get; set; }

        public int? ArticleId { get; set; }

        public string? Location { get; set; }
    }
}
