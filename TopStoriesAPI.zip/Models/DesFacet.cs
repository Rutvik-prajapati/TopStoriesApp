﻿using System;
using System.Collections.Generic;

namespace TopStoriesAPI.Models;

public partial class DesFacet
{
    public int Id { get; set; }

    public int? ArticleId { get; set; }

    public string? Facet { get; set; }

    public virtual Article? Article { get; set; }
}
