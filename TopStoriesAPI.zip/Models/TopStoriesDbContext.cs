﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TopStoriesAPI.Models;

public partial class TopStoriesDbContext : DbContext
{
    public TopStoriesDbContext()
    {
    }

    public TopStoriesDbContext(DbContextOptions<TopStoriesDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Article> Articles { get; set; }

    public virtual DbSet<DesFacet> DesFacets { get; set; }

    public virtual DbSet<GeoFacet> GeoFacets { get; set; }

    public virtual DbSet<Multimedium> Multimedia { get; set; }

    public virtual DbSet<PerFacet> PerFacets { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Article>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Articles__3214EC077BC124B2");

            entity.Property(e => e.Byline).HasMaxLength(255);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ItemType).HasMaxLength(100);
            entity.Property(e => e.Kicker).HasMaxLength(255);
            entity.Property(e => e.MaterialTypeFacet).HasMaxLength(255);
            entity.Property(e => e.PublishedDate).HasColumnType("datetime");
            entity.Property(e => e.Section).HasMaxLength(100);
            entity.Property(e => e.Subsection).HasMaxLength(100);
            entity.Property(e => e.Title).HasMaxLength(500);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.Uri).HasMaxLength(255);
            entity.Property(e => e.Url).HasMaxLength(1000);
        });

        modelBuilder.Entity<DesFacet>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__DesFacet__3214EC07CC6C304D");

            entity.Property(e => e.Facet).HasMaxLength(255);

            entity.HasOne(d => d.Article).WithMany(p => p.DesFacets)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__DesFacets__Artic__29572725");
        });

        modelBuilder.Entity<GeoFacet>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__GeoFacet__3214EC07066798BD");

            entity.Property(e => e.Location).HasMaxLength(255);

            entity.HasOne(d => d.Article).WithMany(p => p.GeoFacets)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__GeoFacets__Artic__2F10007B");
        });

        modelBuilder.Entity<Multimedium>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Multimed__3214EC076AF15D00");

            entity.Property(e => e.Copyright).HasMaxLength(255);
            entity.Property(e => e.Format).HasMaxLength(255);
            entity.Property(e => e.Subtype).HasMaxLength(100);
            entity.Property(e => e.Type).HasMaxLength(100);
            entity.Property(e => e.Url).HasMaxLength(1000);

            entity.HasOne(d => d.Article).WithMany(p => p.Multimedia)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Multimedi__Artic__267ABA7A");
        });

        modelBuilder.Entity<PerFacet>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__PerFacet__3214EC07C3F546A5");

            entity.Property(e => e.Person).HasMaxLength(255);

            entity.HasOne(d => d.Article).WithMany(p => p.PerFacets)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__PerFacets__Artic__2C3393D0");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
