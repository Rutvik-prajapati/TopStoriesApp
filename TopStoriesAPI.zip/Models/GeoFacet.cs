﻿using System;
using System.Collections.Generic;

namespace TopStoriesAPI.Models;

public partial class GeoFacet
{
    public int Id { get; set; }

    public int? ArticleId { get; set; }

    public string? Location { get; set; }

    public virtual Article? Article { get; set; }
}
