﻿using System;
using System.Collections.Generic;

namespace TopStoriesAPI.Models;

public partial class PerFacet
{
    public int Id { get; set; }

    public int? ArticleId { get; set; }

    public string? Person { get; set; }

    public virtual Article? Article { get; set; }
}
