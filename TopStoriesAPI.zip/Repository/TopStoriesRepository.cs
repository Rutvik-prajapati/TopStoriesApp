﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using System.Net;
using TopStoriesAPI.IRepository;
using TopStoriesAPI.Model;
using TopStoriesAPI.Models;

namespace TopStoriesAPI.Repository
{
    public class TopStoriesRepository : GenericRepository<TopStoriesModel>,ITopStories
    {
        private readonly IConfiguration _configuration;
        public TopStoriesRepository(TopStoriesDbContext context, IConfiguration configuration) : base(context)
        {
            _configuration = configuration;
        }
        public TopStoriesModel SaveTopStories(string apikey)
        {
            TopStoriesModel newsResponse = new TopStoriesModel();
            HttpClient client= new HttpClient();
            string apiKeyValue = compareApiKey(apikey);
            string url = $"https://api.nytimes.com/svc/topstories/v2/home.json?api-key={apiKeyValue}";
            try
            {
                HttpResponseMessage response = client.GetAsync(url).Result;
                response.EnsureSuccessStatusCode();
                string responseBody = response.Content.ReadAsStringAsync().Result;
                return newsResponse = JsonConvert.DeserializeObject<TopStoriesModel>(responseBody);
            }
            catch (HttpRequestException e)
            {
                return newsResponse;
            } 
        }

        public string compareApiKey(string apikey)
        {
            string apiKey = string.Empty;
            if (apikey.Equals(_configuration["ApiKey"]))
                apiKey = _configuration["ApiKey"].ToString();
            return apiKey;
        }

        public void Create(TopStoriesModel entity)
        {
            if (entity?.Results?.Count > 0)
            {
                foreach (var article in entity.Results)
                {
                    var newArticle = new Models.Article()
                    {
                        Section = article.Section,
                        Subsection = article.Subsection,
                        Title = article.Title,
                        Abstract = article.Abstract,
                        Url = article.Url,
                        Uri = article.Uri,
                        Byline = article.Byline,
                        ItemType = article.ItemType,
                        UpdatedDate = Convert.ToDateTime(article.UpdatedDate),
                        CreatedDate = Convert.ToDateTime(article.CreatedDate),
                        PublishedDate = Convert.ToDateTime(article.PublishedDate),
                        MaterialTypeFacet = article.MaterialTypeFacet,
                        Kicker = article.Kicker,
                        //ShortUrl = article.ShortUrl
                    };
                    context.Articles.Add(newArticle);
                    context.SaveChanges();

                    if (article?.DesFacet?.Count>0)
                    {
                        foreach (var desFacet in article.DesFacet)
                        {
                            var newDesFacet = new Models.DesFacet()
                            {
                                Facet = desFacet,
                                ArticleId = newArticle.Id
                            };
                            context.DesFacets.Add(newDesFacet);
                            context.SaveChanges();
                        }
                    }
                    if (article?.PerFacet?.Count > 0)
                    {
                        foreach (var perFacet in article.PerFacet)
                        {
                            var newPerFacet = new Models.PerFacet()
                            {
                                Person = perFacet,
                                ArticleId = newArticle.Id
                            };
                            context.PerFacets.Add(newPerFacet);
                            context.SaveChanges();
                        }
                    }
                    if (article?.GeoFacet?.Count > 0)
                    {
                        foreach (var geoFacet in article.GeoFacet)
                        {
                            var newGeoFacet = new Models.GeoFacet()
                            {
                                Location = geoFacet,
                                ArticleId = newArticle.Id
                            };
                            context.GeoFacets.Add(newGeoFacet);
                            context.SaveChanges();
                        }
                    }
                    if (article?.Multimedia?.Count > 0)
                    {
                        foreach (var multimedia in article.Multimedia)
                        {
                            var newMultimedia = new Models.Multimedium()
                            {
                                ArticleId = newArticle.Id,
                                Url = multimedia.Url,
                                Format = multimedia.Format,
                                Height = multimedia.Height,
                                Width = multimedia.Width,
                                Type = multimedia.Type,
                                Subtype = multimedia.Subtype,
                                Caption = multimedia.Caption,
                                Copyright = multimedia.Copyright
                            };
                            context.Multimedia.Add(newMultimedia);
                            context.SaveChanges();
                        }
                    }
                }
            }
        }

        public TopStoriesDtoModel GetAllTopStories()
        {
            var topStoriesDtoModel = new TopStoriesDtoModel();
            topStoriesDtoModel.TopStories = new List<ArticalDto>();
            //topStories = context.Articles
            topStoriesDtoModel.TopStories = context.Articles.Include(a => a.Multimedia).Include(a => a.DesFacets).Include(a => a.PerFacets).Include(a => a.GeoFacets)
                            .Select(a => new ArticalDto
                            {
                                Id = a.Id,
                                Section = a.Section,
                                Subsection = a.Subsection,
                                Title = a.Title,
                                Abstract = a.Abstract,
                                Url = a.Url,
                                Uri = a.Uri,
                                Byline = a.Byline,
                                ItemType = a.ItemType,
                                UpdatedDate = a.UpdatedDate,
                                CreatedDate = a.CreatedDate,
                                PublishedDate = a.PublishedDate,
                                MaterialTypeFacet = a.MaterialTypeFacet,
                                Kicker = a.Kicker,

                                // Mapping related data
                                Multimedia = a.Multimedia.Select(m => new MultimediaDto
                                {
                                    Id = m.Id,
                                    ArticleId = m.ArticleId,
                                    Url = m.Url,
                                    Format = m.Format,
                                    Height = m.Height,
                                    Width = m.Width,
                                    Type = m.Type,
                                    Subtype = m.Subtype,
                                    Caption = m.Caption,
                                    Copyright = m.Copyright
                                }).ToList(),

                                DesFacets = a.DesFacets.Select(d => new DesFacetsDto
                                {
                                    Id = d.Id,
                                    ArticleId = d.ArticleId,
                                    Facet = d.Facet
                                }).ToList(),

                                PerFacets = a.PerFacets.Select(p => new PerFacetsDto
                                {
                                    Id = p.Id,
                                    ArticleId = p.ArticleId,
                                    Person = p.Person
                                }).ToList(),

                                GeoFacets = a.GeoFacets.Select(g => new GeoFacetsDto
                                {
                                    Id = g.Id,
                                    ArticleId = g.ArticleId,
                                    Location = g.Location
                                }).ToList()

                            }
                            ).ToList();

            return topStoriesDtoModel;
        }
    }
}
