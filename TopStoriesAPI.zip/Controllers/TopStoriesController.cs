﻿using Microsoft.AspNetCore.Mvc;
using System.Numerics;
using TopStoriesAPI.IRepository;
using TopStoriesAPI.Model;

namespace TopStoriesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TopStoriesController : Controller
    {
        private readonly ITopStories topStories;

        public TopStoriesController(ITopStories context)
        {
            topStories = context;
        }


        [HttpGet]
        [Route("SaveTopStories")]
        public ActionResult SaveTopStories(string apiKey)
        {
            var topStoriesList = topStories.SaveTopStories(apiKey);
            if (topStoriesList == null)
            {
                return NotFound(topStoriesList);
            }
            else
                //topStories.Create(topStoriesList);
            return Ok(topStoriesList);
        }

        [HttpGet]
        [Route("GetAllStories")]
        public ActionResult GetAllStories()
        {
            TopStoriesDtoModel topStoriesDtoModel =  topStories.GetAllTopStories();

            if (topStoriesDtoModel == null)
            {
                return NotFound();
            }

            return Ok(topStoriesDtoModel);
        }
    }
}
