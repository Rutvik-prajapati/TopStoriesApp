﻿using TopStoriesAPI.Model;

namespace TopStoriesAPI.IRepository
{
    public interface ITopStories : IGenericInterface<TopStoriesModel>
    {
        public TopStoriesModel SaveTopStories(string apikey);
        public TopStoriesDtoModel GetAllTopStories();
    }
}
