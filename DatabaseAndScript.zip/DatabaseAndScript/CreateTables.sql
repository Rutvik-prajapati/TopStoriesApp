CREATE TABLE Articles (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Section NVARCHAR(100),
    Subsection NVARCHAR(100),
    Title NVARCHAR(500),
    Abstract NVARCHAR(MAX),
    Url NVARCHAR(1000),
    Uri NVARCHAR(255),
    Byline NVARCHAR(255),
    ItemType NVARCHAR(100),
    UpdatedDate DATETIME,
    CreatedDate DATETIME,
    PublishedDate DATETIME,
    MaterialTypeFacet NVARCHAR(255),
    Kicker NVARCHAR(255)
);

CREATE TABLE Multimedia (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ArticleId INT FOREIGN KEY REFERENCES Articles(Id) ON DELETE CASCADE,
    Url NVARCHAR(1000),
    Format NVARCHAR(255),
    Height INT,
    Width INT,
    Type NVARCHAR(100),
    Subtype NVARCHAR(100),
    Caption NVARCHAR(MAX),
    Copyright NVARCHAR(255)
);

CREATE TABLE DesFacets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ArticleId INT FOREIGN KEY REFERENCES Articles(Id) ON DELETE CASCADE,
    Facet NVARCHAR(255)
);

CREATE TABLE PerFacets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ArticleId INT FOREIGN KEY REFERENCES Articles(Id) ON DELETE CASCADE,
    Person NVARCHAR(255)
);

CREATE TABLE GeoFacets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ArticleId INT FOREIGN KEY REFERENCES Articles(Id) ON DELETE CASCADE,
    Location NVARCHAR(255)
);
